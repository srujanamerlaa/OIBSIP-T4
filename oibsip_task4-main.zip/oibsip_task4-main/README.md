# oibsip_task4
## Online Examination
The project should be capable of the following functionalities.
1)Login
2)Update Profile and Password
3)Selecting answers for MCQs
4)Timer and auto submit
5)Closing session and Logout
